README_unix.txt for version 8.1 of Vim: Vi IMproved.

This file explains the installation of Vim on Unix systems.
See "README.txt" for general information about Vim.


When you use the source distribution, "make install" is used to install Vim.
See the "INSTALL" file in the "src" directory.

If you use a compiled package, follow the instructions for the package.
