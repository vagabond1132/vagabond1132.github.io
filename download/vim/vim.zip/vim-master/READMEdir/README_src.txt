README_src.txt for version 8.1 of Vim: Vi IMproved.

The source archive contains the files needed to compile Vim on Unix systems.
It is packed for Unix systems (NL line separator).

For more information, see the README.txt file that comes with the runtime
archive (vim-8.1-rt.tar.gz).  To be able to run Vim you MUST get the runtime
archive too!
