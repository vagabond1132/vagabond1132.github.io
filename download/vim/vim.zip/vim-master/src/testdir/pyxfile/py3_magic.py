# requires python 3.x

import sys
print(sys.version)
