#include "postgres.h"
#include "fmgr.h"


#include "tcop/utility.h"

#ifdef PG_MODULE_MAGIC
PG_MODULE_MAGIC;
#endif


void _PG_init(void);
void _PG_fini(void);



static
ProcessUtility_hook_type prev_proccessutility_hook = NULL; // 我们将要使用的Hook;


static
void record_oper_info(Node *parsetree,
                       const char *queryString, ProcessUtilityContext context,
                       ParamListInfo params,
                       DestReceiver *dest, char *completionTag)
{
    ereport(NOTICE, (errmsg("Drop ? it`s not allowd")));

    standard_ProcessUtility(parsetree, queryString,
                            context, params,
                            dest, completionTag);
}


void
_PG_init(void)
{

    prev_proccessutility_hook = ProcessUtility_hook; //将系统; -- 指向系统本身设置;
    ProcessUtility_hook = record_oper_info; //将系统函数 指向 自己定义Func;

}


void
_PG_fini(void)
{
    ProcessUtility_hook = prev_proccessutility_hook;  //卸载时, 在恢复到之前的系统参数；
}
